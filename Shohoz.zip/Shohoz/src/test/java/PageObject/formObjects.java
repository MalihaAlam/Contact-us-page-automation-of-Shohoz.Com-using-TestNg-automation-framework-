package PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class formObjects extends pageobj{





    @FindBy (xpath ="//input[@id='name']")
    public WebElement  yourName;
    @FindBy (xpath ="//input[@id='contactnumber']")
    public WebElement phoneNumber;

    @FindBy (xpath ="//input[@id='email']")
    public WebElement email;

    @FindBy (xpath ="//textarea[@id='comment']")
    public WebElement message;

    @FindBy (xpath ="//body/div[1]/div[1]/div[2]/div[1]/form[1]/div[5]/input[1]")
    public WebElement send;

    public formObjects (WebDriver driver){
        super(driver);
    }

}

