package TestCase;

import Configuration.DriverSetup;
import PageObject.formObjects;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class formTest extends DriverSetup  {

    public static String url= "https://www.shohoz.com/contact-us/en" ;

    @Test
    public static void testFrom() throws InterruptedException {
        driver.get (url);

        driver.manage().window().maximize();


        Thread.sleep(5000);



        formObjects form = new formObjects(driver) ;


        Select drpPurpose = new Select(driver.findElement(By.xpath("//select[@id='purpose']")));
        drpPurpose.selectByVisibleText("Food");
        Thread.sleep(5000);

        Select drpCity = new Select(driver.findElement(By.xpath("//select[@id='city']")));
        drpCity.selectByVisibleText("Dhaka");

        form.yourName.sendKeys("maliha") ;
        form.phoneNumber .sendKeys("01718810929") ;
        form.email.sendKeys("maliha@gmail.com") ;
        form.message.sendKeys("make it shohoz") ;
        Thread.sleep(5000);
        form.send .click();
        Thread.sleep(5000);

    }
}
